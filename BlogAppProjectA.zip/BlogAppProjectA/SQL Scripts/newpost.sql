DELIMITER //
DROP PROCEDURE IF EXISTS newpost // 

CREATE PROCEDURE newpost
(
	IN in_newpost VARCHAR(1000),
	IN in_newtitle VARCHAR(75),
	IN in_username VARCHAR(20)
)
BEGIN
INSERT INTO blogpost
(
	BlogPost, 
	PostTitle,
	Username
)
VALUES(
	in_newpost, 
	in_newtitle,
	in_username
);
END //
DELIMITER ;
