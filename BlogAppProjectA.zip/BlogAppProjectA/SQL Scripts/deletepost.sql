DELIMITER //
DROP PROCEDURE IF EXISTS deletepost// 

CREATE PROCEDURE deletepost
(
	IN in_id INT
)	
BEGIN
	DELETE FROM comments WHERE POSTID = in_id;
	DELETE FROM blogpost WHERE PostID = in_id;
END //
DELIMITER ;
