DELIMITER //
DROP PROCEDURE IF EXISTS newcomment // 

CREATE PROCEDURE newcomment
(
	IN in_newcomment VARCHAR(500),
	IN in_username VARCHAR(20),
	IN in_id INT
)
BEGIN
INSERT INTO comments
(
	CommentPost, 
	Username,
	PostID
)
VALUES(
	in_newcomment, 
	in_username,
	in_id
);
END //
DELIMITER ;
