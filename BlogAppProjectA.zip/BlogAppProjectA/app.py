#!/usr/bin/env python
import sys
from flask import Flask, jsonify, abort, request, make_response, session
from flask_restful import reqparse, Resource, Api
from flask_session import Session
import json
from ldap3 import Server, Connection, ALL
from ldap3.core.exceptions import *

import settings
import pymysql.cursors

import cgitb
import cgi
cgitb.enable()

app = Flask(__name__, static_url_path="/static")
api = Api(app)

app.secret_key = settings.SECRET_KEY
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_COOKIE_NAME'] = 'peanutButter'
app.config['SESSION_COOKIE_DOMAIN'] = settings.APP_HOST
Session(app)

#Database connection
connection = pymysql.connect(host=settings.MYSQL_HOST,
                            user=settings.MYSQL_USER,
                            passwd=settings.MYSQL_PASSWD
                            db=settings.MYSQL_DB,
                            charset='utf8mb4'
                            )

class Root(Resource):
	def get(self):
		return app.send_static_file('index.html')
	class RootBlog(Resource):
    	def get(self):
    		return app.send_static_file('ReadL.html')

####################################################################################
#
# Error handlers

@app.errorhandler(400) # decorators to add to 400 response
def not_found(error):
	return make_response(jsonify( { 'status': 'Bad request' } ), 400)

@app.errorhandler(404) # decorators to add to 404 response
def not_found(error): 
	return make_response(jsonify( { 'status': 'Resource not found' } ), 404)

####################################################################################
class SignIn(Resource):
	# Example curl command:
	# curl -i -H "Content-Type: application/json" -X POST -d '{"username": "jdoe", "password": "password"}' -c cookie-jar -k http://127.0.0.1:51328/signin
	#
	def post(self):

		if not request.json:
			abort(400) # bad request
		# Parse the json
		parser = reqparse.RequestParser()
		try:
			# Check for required attributes in json document, create a dictionary
			parser.add_argument('username', type=str, required=True)
			parser.add_argument('password', type=str, required=True)
			request_params = parser.parse_args()
		except:
			abort(400) # bad request

		if request_params['username'] in session:
			response = {'status': 'success'}
			responseCode = 200
		else:
			try:
				ldapServer = Server(host=settings.LDAP_HOST)
				ldapConnection = Connection(ldapServer,
					raise_exceptions=True,
					user='uid='+request_params['username']+', ou=People,ou=fcs,o=unb',
					password = request_params['password'])
				ldapConnection.open()
				ldapConnection.start_tls()
				ldapConnection.bind()

				session['username'] = request_params['username']
				response = {'status': 'success' }
				responseCode = 201
			except (LDAPException, error_message):
				response = {'status': 'Access denied'}
				responseCode = 403
			finally:
				ldapConnection.unbind()

			return make_response(jsonify(response), responseCode)


	def get(self):
		success = False
		if 'username' in session:
			response = {'status': 'success'}
			responseCode = 200
		else:
			response = {'status': 'fail'}
			responseCode = 403

		return make_response(jsonify(response), responseCode)

	def delete(self):
		success = False
		session.clear()
		if 'username' in session:
			response = {'status': 'fail'}
			responseCode = 403
		else:
			response = {'status': 'success'}
			responseCode = 200

		return make_response(jsonify(response), responseCode)

#####################################################################################
class BlogPost(Resource):
	def post(self):
		if not request.json:
			abort(400)
		blogparser = reqparse.RequestParser()
		try:
			blogparser.add_argument("blogpost", type=str, required=True)
			blogparser.add_argument("blogtitle", type=str, required=True)
			blogparser.add_argument("user", type=str, required=True)

			blog_params = blogparser.parse_args()

			_blogpost = blog_params["blogpost"]
			_blogtitle = blog_params["blogtitle"]
			_bloguser = blog_params["user"]

			cursor = connection.cursor()
			cursor.callproc('newpost',(_blogpost, _blogtitle, _bloguser))
			connection.commit()
			response = {'status': 'post created'}
			responseCode = 200
		except:
			abort(400)

		return make_response(jsonify(response), responseCode)

	def get(self):
		try:
			cursor = connection.cursor()
			cursor.callproc('getBlogPosts')
			results = cursor.fetchall()

			#Code provided
			field_names = [i[0] for i in cursor.description]
			set = [{description: value for description, value in zip(field_names, row)} for row in results]

		except:
			abort(400)

		return make_response(jsonify({'blogpost': set}), 200)

#############################################################################
class BlogPostResources(Resource):

	def get(self, postId):
		try:
			cursor = connection.cursor()
			cursor.callproc('getOneBlog',[postId])
			results = cursor.fetchone()

			print (results)

			response = {'status': 'success'}
			responseCode = 200

		except:
			abort(400)

		return make_response(jsonify(response), responseCode)

	def delete(self, postId):
		try:
			sql = "call deletepost()"
			cursor = connection.cursor()
			cursor.callproc('deletepost',[postId])
			connection.commit()

			response = {'status': 'success'}
			responseCode = 200

		except:
			abort(400)

		return make_response(jsonify(response), responseCode)

#####################################################################################
class Comments(Resource):

	def post(self):
		if not request.json:
			abort(400)
		commentparser = reqparse.RequestParser()
		try:
			commentparser.add_argument("user", type=str, required=True)
			commentparser.add_argument("commentpost", type=str, required=True)
			commentparser.add_argument("postid", type=int, required=True)

			comment_params = commentparser.parse_args()

			_usercomment = comment_params["user"]
			_commentpost = comment_params["commentpost"]
			_blogpostid = comment_params["postid"]

			cursor = connection.cursor()
			cursor.callproc('newcomment',(_commentpost, _usercomment, _blogpostid))
			connection.commit()
			response = {'status': 'post created'}
			responseCode = 200
		except:
			abort(400)

		return make_response(jsonify(response), responseCode)

####################################################################################
class CommentsResource(Resource):

	def get(self, postId):
		try:
			cursor = connection.cursor()
			cursor.callproc('getComments',[postId])
			results = cursor.fetchall()

			field_names = [i[0] for i in cursor.description]
			set = [{description: value for description, value in zip(field_names, row)} for row in results]

		except:
			abort(400)

		return make_response(jsonify({'comments': set}), 200)

####################################################################################
class Hello(Resource):

	def get(self):
		if 'username' in session:
			response = {'status': 'success', 'message': 'Welcome ' + session['username']}
			responseCode = 200
		else:
			response = {'status': 'fail', 'message': 'Try again.'}
			responseCode = 403

		return make_response(jsonify(response), responseCode)


####################################################################################

api = Api(app)
api.add_resource(SignIn, '/signin')
api.add_resource(BlogPost, '/blogpost')
api.add_resource(BlogPostResources, '/blogpost/<int:postId>')
api.add_resource(Comments, '/comments')
api.add_resource(CommentsResource, '/comments/<int:postId>')
api.add_resource(Hello, '/hello')
api.add_resource(Root, '/')
api.add_resource(RootBlog, '/bloghome')

####################################################################################
if __name__ == "__main__":
   	app.run(host=settings.APP_HOST, port=settings.APP_PORT, debug=settings.APP_DEBUG)

