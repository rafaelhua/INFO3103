#/usr/bin/env python

APP_HOST = 'info3103.cs.unb.ca'
APP_PORT =  51326
APP_DEBUG = True

MYSQL_HOST = 'localhost'
MYSQL_USER = 'jhua'
MYSQL_PASSWD = 'AD09nZCG'
MYSQL_DB = 'jhua'

SECRET_KEY = 'd41d8cd98f00b204e9800998ecf8427f'

LDAP_HOST =  'ldap-student.cs.unb.ca'
