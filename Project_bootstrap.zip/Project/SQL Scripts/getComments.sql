DELIMITER // 
DROP PROCEDURE IF EXISTS getComments //

CREATE PROCEDURE getComments
(
	IN in_id INT
)
BEGIN 
	SELECT * FROM comments WHERE PostID = in_id;
END // 
DELIMITER; 
